# Module: Ruleset Versioning

## 🔍 Summary
Organize rules using versioned rulesets to support structured deployment.

## ✅ Best Practices
- Follow naming convention: AppName:Layer:Version.
- Lock old versions to prevent changes post-deployment.

## 🛠 Example
Ruleset: HRApp:Data:01-01-01 → 01-01-02 (patch)

## 🧯 Troubleshooting
- Rule not found? Check ruleset stack and version availability.

## 📚 References
[Pega Docs – Rulesets](https://docs.pega.com/application-development/rulesets)
