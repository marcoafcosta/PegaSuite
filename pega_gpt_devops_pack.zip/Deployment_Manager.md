# Module: Deployment Manager

## 🔍 Summary
Deployment Manager automates CI/CD using pipelines across environments.

## ✅ Best Practices
- Use four-stage pipelines: Dev → QA → Staging → Prod.
- Automate approvals when possible.

## 🛠 Example
Pipeline: HR App Deployment
- Tasks: Unit test → Security scan → Approval → Import

## 🧯 Troubleshooting
- Pipeline fails? Check product rule version and artifact repo connection.

## 📚 References
[Pega Docs – Deployment Manager](https://docs.pega.com/devops/deployment-manager)
