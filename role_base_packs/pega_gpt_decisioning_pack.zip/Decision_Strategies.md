# Module: Decision Strategies

## 🔍 Summary
Decision strategies define logic to determine the best action or offer based on business and customer data.

## ✅ Best Practices
- Use engagement policies to filter propositions.
- Use adaptive models for AI-based predictions.

## 🛠 Example
Strategy: Cross-sell product offer
- Filter: Customer has no existing subscription
- Arbitration: Highest propensity

## 🧯 Troubleshooting
- Strategy not compiling? Check for unconnected shapes or invalid inputs.

## 📚 References
[Pega Docs – Decision Strategies](https://docs.pega.com/decision-management)
