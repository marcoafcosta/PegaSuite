# Module: Proposition Management

## 🔍 Summary
Manage offers and treatments using proposition hierarchies in Pega Decisioning.

## ✅ Best Practices
- Organize by Issue and Group (e.g., Credit → Cards).
- Store metadata (priority, channel) in proposition properties.

## 🛠 Example
Issue: Retention → Group: Mobile Plan → Proposition: 5GB Discount Plan

## 🧯 Troubleshooting
- Offer not appearing in strategy? Ensure it meets engagement policy conditions.

## 📚 References
[Pega Docs – Proposition Management](https://docs.pega.com/decision-management/proposition-management)
