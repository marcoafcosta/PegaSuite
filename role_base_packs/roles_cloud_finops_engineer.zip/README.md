# Role: Cloud FinOps Engineer

Optimizes Pega Cloud deployments for cost, observability, and sustainability.
...