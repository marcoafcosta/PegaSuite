# Module: Data Pages

## 🔍 Summary
Data Pages are used to load and cache data, supporting different scopes: Thread, Requestor, and Node.

## ✅ Best Practices
- Use Node-level for shared read-only config data.
- Prefer Load-Data Page over Load-Activity.
- Always set refresh conditions for dynamic data.

## 🛠 Example
D_Countries
- Scope: Node
- Source: REST Connector

## 🧯 Troubleshooting
- "Data Page Not Found": Check scope or parameters.
- Use Clipboard to verify loaded data.

## 📚 References
[Pega Docs – Data Pages](https://docs.pega.com/data-management/87/data-pages)
