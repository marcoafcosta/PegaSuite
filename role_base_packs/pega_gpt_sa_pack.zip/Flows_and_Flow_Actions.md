# Module: Flows and Flow Actions

## 🔍 Summary
Flows define the sequence of tasks in a process, while flow actions allow user input and transitions.

## ✅ Best Practices
- Keep flows simple and modular.
- Use subprocesses to avoid duplication.
- Avoid more than 7 shapes per screen flow.

## 🛠 Example
Flow: LoanRequestFlow
- Subflows: ApprovalSubflow, ReviewSubflow

## 🧯 Troubleshooting
- "Flow Not At Task": Check for incorrect flow shape transitions.

## 📚 References
[Pega Docs – Flow Rules](https://docs.pega.com/process/flow-rules)
