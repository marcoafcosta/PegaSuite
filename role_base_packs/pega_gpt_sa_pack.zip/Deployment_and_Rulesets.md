# Module: Deployment & Rulesets

## 🔍 Summary
Package and deploy applications using rulesets, branches, and deployment pipelines.

## ✅ Best Practices
- Use branches per feature team.
- Validate ruleset versions before merging.

## 🛠 Example
Ruleset: LoanApp:LoanCase:01-01
- Feature Branch: LoanCaseApproval

## 🧯 Troubleshooting
- Merge conflict? Resolve via branch comparison in Dev Studio.

## 📚 References
[Pega Docs – Deployment Manager](https://docs.pega.com/devops/deployment-manager)
