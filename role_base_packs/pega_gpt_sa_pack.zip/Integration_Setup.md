# Module: Integration Setup

## 🔍 Summary
Integrate with external systems using Connectors and Services. Use Data Pages for decoupling.

## ✅ Best Practices
- Test connectors using the Dev Studio wizard.
- Avoid hardcoded URLs; use DSS or dynamic system settings.

## 🛠 Example
Connector: Connect-REST to CRM system
- Used by: D_CustomerProfile

## 🧯 Troubleshooting
- Authentication issues: check authentication profile and endpoint.

## 📚 References
[Pega Docs – Integration](https://docs.pega.com/integration)
