# Module: Business Rules and Activities

## 🔍 Summary
Implement logic using When rules, Data Transforms, Decision Tables, and Activities (only when necessary).

## ✅ Best Practices
- Use Activities sparingly, only when no other rule fits.
- Reuse logic via Data Transforms or Declare rules.

## 🛠 Example
Data Transform: SetDefaultValues (used in pyDefault)

## 🧯 Troubleshooting
- Overridden logic? Check rule resolution order and circumstancing.

## 📚 References
[Pega Docs – Activities](https://docs.pega.com/business-rules)
