# Module: Node Management and Agents

## 🔍 Summary
Manage background processing using agents and job schedulers.

## ✅ Best Practices
- Use job schedulers for recurring jobs (post 8.3).
- Disable unnecessary agents on nodes.

## 🛠 Example
Job Scheduler: ArchiveResolvedCases runs weekly on background node.

## 🧯 Troubleshooting
- Task skipped? Check node type and log file for agent exceptions.

## 📚 References
[Pega Docs – Job Schedulers](https://docs.pega.com/job-schedulers)
