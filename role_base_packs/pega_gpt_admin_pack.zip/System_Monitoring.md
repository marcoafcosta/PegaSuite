# Module: System Monitoring

## 🔍 Summary
Monitor system health using Pega Autonomic Event Services (AES) or PDC.

## ✅ Best Practices
- Set thresholds for CPU, DB connection pool, and queue processors.
- Investigate alerts proactively.

## 🛠 Example
High DB time alert for Report Definition → Optimized indexing needed.

## 🧯 Troubleshooting
- No alerts in PDC? Ensure proper configuration and agent activity.

## 📚 References
[Pega Docs – System Monitoring](https://docs.pega.com/system-administration/monitoring)
