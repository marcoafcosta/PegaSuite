# Module: Skin and Styling

## 🔍 Summary
Control application branding and look-and-feel using skin and format rules.

## ✅ Best Practices
- Use format inheritance to minimize duplication.
- Test accessibility contrast for color choices.

## 🛠 Example
Skin: HRAppSkin
- Button format: PrimaryButton (blue with white text)

## 🧯 Troubleshooting
- Style not applying? Clear browser cache and regenerate skin.

## 📚 References
[Pega Docs – Skin Rules](https://docs.pega.com/user-experience/skin-rules)
