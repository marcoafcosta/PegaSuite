# Module: Harnesses and Portals

## 🔍 Summary
Harnesses control screen content and layout; portals define user access points.

## ✅ Best Practices
- Reuse harnesses across case types.
- Customize portals for different personas.

## 🛠 Example
Portal: HRManagerPortal
Harness: Perform → used for case interaction

## 🧯 Troubleshooting
- Broken layout? Check harness container and region visibility.

## 📚 References
[Pega Docs – Portals and Harnesses](https://docs.pega.com/user-experience/portals)
