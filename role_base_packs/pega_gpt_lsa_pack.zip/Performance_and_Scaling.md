# Module: Performance and Scaling

## 🔍 Summary
Design for performance and scalability using caching, load balancing, and efficient rule usage.

## ✅ Best Practices
- Use Node-level data pages for shared reference data.
- Minimize clipboard footprint using optimized load strategies.

## 🛠 Example
Node-level cache: D_Countries (auto-refresh weekly)

## 🧯 Troubleshooting
- Sluggish performance? Review PAL and DB query stats.

## 📚 References
[Pega Docs – Performance Tuning](https://docs.pega.com/performance)
