# Module: Guardrails and Anti-Patterns

## 🔍 Summary
Ensure applications follow best practices to maximize maintainability and upgradeability.

## ✅ Best Practices
- Use guardrail warnings as guidance.
- Avoid custom Java steps unless absolutely necessary.

## 🛠 Example
Avoid: Deeply nested flows and unnecessary activity rules.

## 🧯 Troubleshooting
- Excessive warnings? Review rule types and follow design alternatives.

## 📚 References
[Pega Docs – Guardrails](https://docs.pega.com/best-practices)
