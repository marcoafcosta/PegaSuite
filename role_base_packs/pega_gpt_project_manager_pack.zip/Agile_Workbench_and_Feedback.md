# Module: Agile Workbench and Feedback

## 🔍 Summary
Capture feedback, user stories, and bugs directly in App Studio using Agile Workbench.

## ✅ Best Practices
- Encourage real-time feedback during demos.
- Link stories to case types and features.

## 🛠 Example
Story: "As a user, I want to track onboarding status" → Linked to Onboarding case.

## 🧯 Troubleshooting
- Story not visible? Check application context and backlog filtering.

## 📚 References
[Pega Docs – Agile Workbench](https://docs.pega.com/agile/agile-workbench)
