# Module: Model Export and Evaluation

## 🔍 Summary
Export, retrain, and evaluate models using external ML platforms.

## ✅ Best Practices
- Use PMML or JSON export formats.
- Track model lifecycle in a versioned repository.

## 🛠 Example
Export adaptive model to evaluate on AWS SageMaker.

## 🧯 Troubleshooting
- Export failed? Validate Prediction Studio model compatibility.

## 📚 References
[Pega Docs – Model Export](https://docs.pega.com/ai-and-decisioning/model-management)
