# Module: Product Rules and Archives

## 🔍 Summary
Package application changes using Product rules and manage versions through archives.

## ✅ Best Practices
- Include only needed classes and rules.
- Use versioning tags for traceability.

## 🛠 Example
Product Rule: ClaimsApp:01.01 → Includes: Cases, Data Types, Flows

## 🧯 Troubleshooting
- Rule missing? Check product rule content and filters.

## 📚 References
[Pega Docs – Product Rules](https://docs.pega.com/devops/product-rules)
