# Module: Pipeline Configuration

## 🔍 Summary
Define automated deployment pipelines using Deployment Manager.

## ✅ Best Practices
- Use gated approval for higher environments.
- Automate test and security scan steps.

## 🛠 Example
Pipeline: Claims App → Dev → QA → UAT → Prod

## 🧯 Troubleshooting
- Task failed? Check Deployment Manager logs and artifact settings.

## 📚 References
[Pega Docs – Deployment Pipelines](https://docs.pega.com/devops/deployment-manager)
