# Module: Model Management

## 🔍 Summary
Manage predictive, adaptive, and text models within Pega Prediction Studio.

## ✅ Best Practices
- Monitor model performance over time.
- Use Champion/Challenger framework to compare models.

## 🛠 Example
Adaptive Model: Predict likelihood of churn → Monitored via Performance tab

## 🧯 Troubleshooting
- Model not visible? Check access to Prediction Studio and model scope.

## 📚 References
[Pega Docs – Model Management](https://docs.pega.com/ai-and-decisioning)
