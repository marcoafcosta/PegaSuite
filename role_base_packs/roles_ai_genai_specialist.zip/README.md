# Role: AI / GenAI Specialist

Focuses on GenAI integration with Pega, prompt engineering, orchestration, and governance.
...