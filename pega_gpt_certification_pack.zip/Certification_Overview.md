# Module: Pega Certification Overview

## 🔍 Summary
Pega offers certifications for various roles across business and technical tracks.

## 🧾 Certifications
- Pega Certified System Architect (PCSA)
- Pega Certified Senior System Architect (PCSSA)
- Pega Certified Lead System Architect (PCLSA)
- Pega Certified Business Architect (PCBA)
- Pega Certified Decisioning Consultant (PCDC)
- Pega Certified Marketing Consultant (PCMC)
- Pega Robotics System Architect (PCRSA)
- Pega Data Scientist (PCDS)

## 📚 References
[Pega Academy Certification Paths](https://academy.pega.com/paths)
