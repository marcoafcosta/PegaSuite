# Module: Pega Certified Decisioning Consultant (PCDC) Prep

## 🧠 Key Topics
- NBA Designer
- Strategy Design and Arbitration
- Proposition Management
- Simulations and Reports

## ✅ Tips
- Know the full lifecycle of a Next-Best-Action.
- Understand how to build and troubleshoot a decision strategy.
- Focus on channels and engagement policies.

## 📚 References
[Pega PCDC Course](https://academy.pega.com/learning/paths/decisioning)
