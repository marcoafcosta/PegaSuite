# Module: Pega Certified Business Architect (PCBA) Prep

## 🧠 Key Topics
- Case Design and DCO
- Personas, Channels, and Stages
- Reports and Dashboards
- Feedback and Agile Workbench

## ✅ Tips
- Know App Studio inside out.
- Be able to model a process using business terms.
- Review Pega Express methodology.

## 📚 References
[Pega PCBA Course](https://academy.pega.com/learning/paths/business-architect)
