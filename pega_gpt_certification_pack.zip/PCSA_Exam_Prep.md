# Module: Pega Certified System Architect (PCSA) Prep

## 🧠 Key Topics
- App Studio & Case Lifecycle
- Data Pages and Data Transforms
- Decision Rules and Validation
- UI Configuration and Portals
- Application Structure and Rulesets

## ✅ Tips
- Focus on App Studio-first design.
- Practice creating simple case types.
- Know when to use data transforms vs. activities.

## 🧪 Practice
- Take quizzes from Pega Academy.
- Review hands-on exercises from "System Architect" course.

## 📚 References
[Pega PCSA Course](https://academy.pega.com/learning/paths/system-architect)
