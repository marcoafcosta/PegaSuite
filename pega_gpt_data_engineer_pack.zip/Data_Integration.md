# Module: Data Integration

## 🔍 Summary
Ingest and transform external data using connectors and data pages.

## ✅ Best Practices
- Use Data Pages as integration abstraction layers.
- Use response data transforms for mapping.

## 🛠 Example
Connect-REST to CRM → D_CustomerProfile (Requestor scope)

## 🧯 Troubleshooting
- Data not loaded? Validate authentication profiles and connector test results.

## 📚 References
[Pega Docs – Integration](https://docs.pega.com/integration)
