# Module: Data Modeling

## 🔍 Summary
Design reusable, scalable class structures and relationships.

## ✅ Best Practices
- Use inheritance: Work-, Data-, and Org-level classes.
- Normalize reusable entities into data types.

## 🛠 Example
Class: Data-Org-Employee with embedded list of addresses.

## 🧯 Troubleshooting
- Property not saving? Check for clipboard page name conflicts.

## 📚 References
[Pega Docs – Data Modeling](https://docs.pega.com/data-management)
