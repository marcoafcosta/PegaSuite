# Module: Data Governance

## 🔍 Summary
Implement data quality, consistency, and lifecycle policies.

## ✅ Best Practices
- Define property types and validation rules.
- Archive old data using purge/archive processes.

## 🛠 Example
Validation rule: Employee age must be > 18

## 🧯 Troubleshooting
- Inconsistent formats? Review transform rules and input validation.

## 📚 References
[Pega Docs – Data Governance](https://docs.pega.com/data-management/data-quality)
