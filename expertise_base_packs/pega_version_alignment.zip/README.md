# Pega Version Alignment / Roadmap Guidance

This pack documents key capabilities in the Pega 8.8 → 24.x / Infinity ’25 era, and provides guidance on migration, feature adoption, and version-specific design patterns.
...