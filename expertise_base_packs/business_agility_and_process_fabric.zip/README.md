# Business Agility and Pega Process Fabric

Includes federated case management, App Studio bridges, and integration with Process Fabric Hub.
...