# GenAI & Copilot Enablement for Pega

This pack contains guidance, patterns, governance, and implementation artifacts for enabling Pega GenAI™ and Copilot in your organization.
...