# Case Management And Lifecycle

**Overview:** Explain the purpose and scope of Case Management And Lifecycle in Pega projects.
