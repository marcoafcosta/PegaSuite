# Case Management & Lifecycle

Overview and key concepts for Case Management & Lifecycle.
