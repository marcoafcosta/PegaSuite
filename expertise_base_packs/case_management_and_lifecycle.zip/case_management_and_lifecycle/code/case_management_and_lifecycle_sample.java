package com.example.pega.case_management_and_lifecycle;

import java.util.List;
import com.pega.api.PegaAPI;

/**
 * Rich Java class for Case Management And Lifecycle, demonstrating PegaAPI invocation.
 */
public class CaseManagementAndLifecycleDelegate {
    public void execute(List<String> items) {
        // Initialize process
        PegaAPI.runProcess("case_management_and_lifecycle_process", items);
        // Process results
        items.forEach(item -> System.out.println("Processed: " + item));
    }
}
