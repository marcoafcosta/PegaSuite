package com.example.pega.case_management;

import com.pega.pegarules.pub.activity.ActivityWorkHelper;

public class ComplaintAssignment {
    public void assignToTeam(ActivityWorkHelper helper) {
        String severity = helper.getParamValue("pySeverity");
        if ("High".equalsIgnoreCase(severity)) {
            helper.getAgent().setOperatorID("HighPriorityQueue");
        } else {
            helper.getAgent().setOperatorID("StandardQueue");
        }
    }
}
