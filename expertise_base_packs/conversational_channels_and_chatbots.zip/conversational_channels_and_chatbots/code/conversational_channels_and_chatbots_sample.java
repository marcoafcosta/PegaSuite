package com.example.pega.conversational_channels_and_chatbots;

import java.util.List;
import com.pega.api.PegaAPI;

/**
 * Rich Java class for Conversational Channels And Chatbots, demonstrating PegaAPI invocation.
 */
public class ConversationalChannelsAndChatbotsDelegate {
    public void execute(List<String> items) {
        // Initialize process
        PegaAPI.runProcess("conversational_channels_and_chatbots_process", items);
        // Process results
        items.forEach(item -> System.out.println("Processed: " + item));
    }
}
