# Conversational Channels And Chatbots

**Overview:** Explain the purpose and scope of Conversational Channels And Chatbots in Pega projects.
