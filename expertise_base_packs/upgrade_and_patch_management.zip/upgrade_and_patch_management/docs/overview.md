# Upgrade And Patch Management

**Overview:** Explain the purpose and scope of Upgrade And Patch Management in Pega projects.
