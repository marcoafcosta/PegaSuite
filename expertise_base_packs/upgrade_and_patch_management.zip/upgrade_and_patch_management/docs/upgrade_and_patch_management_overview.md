# Upgrade & Patch Management

Overview and key concepts for Upgrade & Patch Management.
