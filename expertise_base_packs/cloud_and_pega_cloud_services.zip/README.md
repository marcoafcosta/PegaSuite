# Cloud and Pega Cloud Services (Updated)

Expanded with Pega Cloud Choice (Kubernetes), Observability integrations (Datadog, Splunk), and sustainability practices.
...