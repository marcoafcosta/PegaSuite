# DevOps and Deployment Automation (Updated)

Covers Deployment Manager 6.x pipelines, microservices deployment, and Constellation-based pipeline configuration.
...