package com.example.pega.decisioning_and_next-best-action;

import java.util.List;
import com.pega.api.PegaAPI;

/**
 * Rich Java class for Decisioning And Next-best-action, demonstrating PegaAPI invocation.
 */
public class DecisioningAndNext-best-actionDelegate {
    public void execute(List<String> items) {
        // Initialize process
        PegaAPI.runProcess("decisioning_and_next-best-action_process", items);
        // Process results
        items.forEach(item -> System.out.println("Processed: " + item));
    }
}
