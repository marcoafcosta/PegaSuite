# Decisioning And Next-best-action

**Overview:** Explain the purpose and scope of Decisioning And Next-best-action in Pega projects.
