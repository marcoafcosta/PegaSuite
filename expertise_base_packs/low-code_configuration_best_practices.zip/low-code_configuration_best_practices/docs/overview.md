# Low-code Configuration Best Practices

**Overview:** Explain the purpose and scope of Low-code Configuration Best Practices in Pega projects.
