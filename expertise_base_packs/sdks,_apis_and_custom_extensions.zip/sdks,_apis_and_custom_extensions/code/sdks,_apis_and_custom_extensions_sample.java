package com.example.pega.sdks,_apis_and_custom_extensions;

import java.util.List;
import com.pega.api.PegaAPI;

/**
 * Rich Java class for Sdks, Apis And Custom Extensions, demonstrating PegaAPI invocation.
 */
public class Sdks,ApisAndCustomExtensionsDelegate {
    public void execute(List<String> items) {
        // Initialize process
        PegaAPI.runProcess("sdks,_apis_and_custom_extensions_process", items);
        // Process results
        items.forEach(item -> System.out.println("Processed: " + item));
    }
}
