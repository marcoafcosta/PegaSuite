# Sdks, Apis And Custom Extensions

**Overview:** Explain the purpose and scope of Sdks, Apis And Custom Extensions in Pega projects.
