# System Architecture And Governance

**Overview:** Explain the purpose and scope of System Architecture And Governance in Pega projects.
