# Performance Tuning And Scalability

**Overview:** Explain the purpose and scope of Performance Tuning And Scalability in Pega projects.
