# Decisioning and Next Best Action (Updated)

Enhanced to include Adaptive Decisioning 2.0, Value Finder, Treatment Simulation, and GenAI in CDH.
...