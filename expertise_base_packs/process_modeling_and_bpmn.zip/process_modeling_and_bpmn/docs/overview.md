# Process Modeling And Bpmn

**Overview:** Explain the purpose and scope of Process Modeling And Bpmn in Pega projects.
