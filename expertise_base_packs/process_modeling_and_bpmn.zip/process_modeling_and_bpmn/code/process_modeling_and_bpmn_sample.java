package com.example.pega.process_modeling_and_bpmn;

import java.util.List;
import com.pega.api.PegaAPI;

/**
 * Rich Java class for Process Modeling And Bpmn, demonstrating PegaAPI invocation.
 */
public class ProcessModelingAndBpmnDelegate {
    public void execute(List<String> items) {
        // Initialize process
        PegaAPI.runProcess("process_modeling_and_bpmn_process", items);
        // Process results
        items.forEach(item -> System.out.println("Processed: " + item));
    }
}
