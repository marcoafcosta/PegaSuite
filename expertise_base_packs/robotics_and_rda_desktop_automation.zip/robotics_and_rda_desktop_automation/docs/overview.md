# Robotics And Rda Desktop Automation

**Overview:** Explain the purpose and scope of Robotics And Rda Desktop Automation in Pega projects.
