# Robotics & RDA (Desktop Automation)

Overview and key concepts for Robotics & RDA (Desktop Automation).
