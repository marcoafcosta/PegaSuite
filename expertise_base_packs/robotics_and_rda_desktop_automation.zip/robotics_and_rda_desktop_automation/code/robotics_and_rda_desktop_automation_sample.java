package com.example.pega.robotics_and_rda_desktop_automation;

import java.util.List;
import com.pega.api.PegaAPI;

/**
 * Rich Java class for Robotics And Rda Desktop Automation, demonstrating PegaAPI invocation.
 */
public class RoboticsAndRdaDesktopAutomationDelegate {
    public void execute(List<String> items) {
        // Initialize process
        PegaAPI.runProcess("robotics_and_rda_desktop_automation_process", items);
        // Process results
        items.forEach(item -> System.out.println("Processed: " + item));
    }
}
