package com.example.pega.blueprint_and_discovery;

import java.util.List;
import com.pega.api.PegaAPI;

/**
 * Rich Java class for Blueprint And Discovery, demonstrating PegaAPI invocation.
 */
public class BlueprintAndDiscoveryDelegate {
    public void execute(List<String> items) {
        // Initialize process
        PegaAPI.runProcess("blueprint_and_discovery_process", items);
        // Process results
        items.forEach(item -> System.out.println("Processed: " + item));
    }
}
