# Blueprint And Discovery

**Overview:** Explain the purpose and scope of Blueprint And Discovery in Pega projects.
