# Security And Access Control

**Overview:** Explain the purpose and scope of Security And Access Control in Pega projects.
