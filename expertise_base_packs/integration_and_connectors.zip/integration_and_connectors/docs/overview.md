# Integration And Connectors

**Overview:** Explain the purpose and scope of Integration And Connectors in Pega projects.
