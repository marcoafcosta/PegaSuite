# Module: App Studio – Forms & Fields

## 🔍 Summary
Configure forms, fields, and validation using low-code tools.

## ✅ Best Practices
- Use intuitive labels for end-users.
- Mark required fields clearly.
- Reuse fields via data types.

## 🛠 Example
Field Group: Employee Details (First Name, Last Name, Department)

## 🧯 Troubleshooting
- Can't save form? Check for unconfigured required fields.

## 📚 References
[Pega Docs – App Studio UI](https://docs.pega.com/user-experience)
