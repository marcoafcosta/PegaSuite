# Module: Personas and Channels

## 🔍 Summary
Define user roles and how they interact with the application.

## ✅ Best Practices
- Create Personas for each unique user role.
- Configure Channels (Web, Email, Mobile) early.

## 🛠 Example
Personas:
- HR Manager (Web Portal)
- New Employee (Mobile)

## 🧯 Troubleshooting
- Persona not available? Ensure it's added to the application profile.

## 📚 References
[Pega Docs – Personas and Channels](https://docs.pega.com/mobile)
