# Module: Case Design for Business Architects

## 🔍 Summary
Designing case types with clear business workflows using App Studio.

## ✅ Best Practices
- Use business-friendly stage names.
- Keep each step action-oriented (e.g., "Review Application").
- Capture business intent with description and personas.

## 🛠 Example
Case Type: Employee Onboarding
- Stages: Initiate → Approve → Setup Workspace → Confirm Start

## 🧯 Troubleshooting
- Can't add step? Ensure stage is marked as "Primary".

## 📚 References
[Pega Docs – Case Types](https://docs.pega.com/case-management)
