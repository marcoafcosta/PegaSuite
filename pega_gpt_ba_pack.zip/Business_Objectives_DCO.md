# Module: Business Objectives & DCO

## 🔍 Summary
Capture business goals and align requirements using Direct Capture of Objectives (DCO).

## ✅ Best Practices
- Document objectives using App Studio.
- Link objectives to case types and stages.

## 🛠 Example
Objective: "Reduce onboarding time"
- Linked to: Employee Onboarding → Setup Workspace

## 🧯 Troubleshooting
- Objectives not visible? Check case type configuration.

## 📚 References
[Pega Docs – DCO](https://docs.pega.com/implementing-applications/direct-capture-objectives)
