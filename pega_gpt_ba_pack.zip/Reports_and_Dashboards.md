# Module: Reports & Dashboards

## 🔍 Summary
Use reporting tools to gain insight into case performance and KPIs.

## ✅ Best Practices
- Use Report Browser for basic reports.
- Create role-specific dashboards.

## 🛠 Example
Report: "Open Cases by Stage"
Dashboard Widget: "HR Manager KPIs"

## 🧯 Troubleshooting
- No results? Check report filters and access roles.

## 📚 References
[Pega Docs – Reporting](https://docs.pega.com/reporting)
