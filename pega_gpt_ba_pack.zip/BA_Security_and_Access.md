# Module: Security & Access for BAs

## 🔍 Summary
Understand how to request and configure access roles for business users.

## ✅ Best Practices
- Work with system architects to define roles.
- Use Access Groups to control visibility.

## 🛠 Example
Access Group: HRManagerAG → Persona: HR Manager

## 🧯 Troubleshooting
- Missing menu items? Check Access Group role privileges.

## 📚 References
[Pega Docs – Access Groups](https://docs.pega.com/security/access-groups)
