# Module: Attribute-Based Access Control (ABAC)

## 🔍 Summary
Control access to specific fields or records based on property values and user context.

## ✅ Best Practices
- Use ABAC for sensitive data fields (e.g., SSN).
- Test ABAC using test users with limited roles.

## 🛠 Example
Policy: Users can only see their own profile (UserID match required)

## 🧯 Troubleshooting
- Field not visible? Check ABAC policy conditions.

## 📚 References
[Pega Docs – ABAC](https://docs.pega.com/security/abac)
