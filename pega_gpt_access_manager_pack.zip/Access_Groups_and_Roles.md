# Module: Access Groups and Roles

## 🔍 Summary
Access Groups control what roles and rulesets a user can access in the application.

## ✅ Best Practices
- Map roles based on job function.
- Use inheritance to simplify role configurations.

## 🛠 Example
Access Group: HRManagerAG → Roles: HRUserRole, ReportViewer

## 🧯 Troubleshooting
- Access denied? Check Access Role to Object (ARO) entries.

## 📚 References
[Pega Docs – Access Groups](https://docs.pega.com/security/access-groups)
