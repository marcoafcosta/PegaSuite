# Module: Accessibility and Responsiveness

## 🔍 Summary
Design inclusive and responsive UIs across devices and accessibility needs.

## ✅ Best Practices
- Follow WCAG guidelines.
- Use semantic components from App Studio.

## 🛠 Example
Screen reader compatible layout with labeled buttons and tab order.

## 🧯 Troubleshooting
- Element skipped by screen reader? Check ARIA attributes and focus order.

## 📚 References
[Pega Docs – Accessibility](https://docs.pega.com/user-experience/accessibility)
