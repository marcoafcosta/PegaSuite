# Module: Unit Testing

## 🔍 Summary
Test individual rules (e.g., Decision Tables, Data Transforms) for accuracy.

## ✅ Best Practices
- Use PegaUnit test cases for reusable, automated checks.
- Mock external data where possible.

## 🛠 Example
Test case for Data Transform: SetDefaultValues

## 🧯 Troubleshooting
- Test fails? Review test inputs and expected values.

## 📚 References
[Pega Docs – PegaUnit](https://docs.pega.com/quality/testing-applications)
