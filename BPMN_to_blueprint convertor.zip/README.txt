bpmn2blueprint_full.py

Comprehensive BPMN → Blueprint converter and packager.

Instructions:
1. Ensure you have Python 3, `bpmn_python`, `PyYAML`, and `blueprint-cli` installed.
2. Place your BPMN file in `diagrams/`.
3. Run the script:
   python bpmn2blueprint_full.py --input diagrams/MyProcess.bpmn --output blueprints/MyProcess.blueprint --strict
4. Find the generated zip alongside the blueprint file for App Studio import.
