# Module: Audit Logging and Security

## 🔍 Summary
Track system and user activity for compliance reporting.

## ✅ Best Practices
- Enable field-level audit for sensitive data.
- Monitor Access Group changes and logins.

## 🛠 Example
Audit: All changes to SSN field tracked and stored in audit trail.

## 🧯 Troubleshooting
- Logs not capturing changes? Check audit configuration on properties.

## 📚 References
[Pega Docs – Audit Logging](https://docs.pega.com/security/audit-logging)
