# Troubleshooting & Compatibility

Ensure all resources validate against standard tools:

- **BPMN**: Validate `.bpmn` in Camunda Modeler or bpmn.io; ensure namespaces match BPMN 2.0 XSD.  
- **Pega XML**: Import `_pega.xml` into Dev Studio; check for correct `xmlns` and `pyName` attributes.  
- **Custom XML**: Use `xmllint --noout blueprint_schema.xsd blueprint_example.xml` to validate.  
- **Java Code**: Build with Maven or your IDE, ensuring `package com.example.pega.blueprint;` matches folder structure.  
- **Markdown**: Render via VSCode or GitHub Preview; check links and code fences.

| Issue                | Tool                     | Command/Fix                                           |
|----------------------|--------------------------|-------------------------------------------------------|
| XML schema errors    | xmllint                  | xmllint --noout --schema blueprint_schema.xsd $FILE   |
| BPMN errors          | Camunda Modeler          | File → Open File; correct namespace declarations      |
| Java compilation     | Maven (`mvn compile`)    | Check `package` path; update `pom.xml` if needed      |
| Missing front-matter | Markdown lint (`mdl`)    | Add YAML front-matter: `---
title: Example
---`     |
