# Blueprint & Discovery

Overview and key concepts for Blueprint & Discovery.
