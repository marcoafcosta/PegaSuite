# Core Concepts

## Business Capability Model
A hierarchical map of the organization’s functions, showing capabilities in a business domain.

## Process Blueprint
A high-level representation of end-to-end processes, typically modeled in BPMN and annotated with system roles.

## Data Blueprint
Defines key entities, attributes, and relationships in an ERD style to guide class structure in Pega.

## Stakeholder Personas
Profiles of users and roles to tailor workshops, ensuring all viewpoints (e.g., business, IT, compliance) are considered.

## Artifact Relationships
- **Capabilities** drive **Processes**; processes map to **Data Models**.
- Personas inform user tasks and design decisions.
