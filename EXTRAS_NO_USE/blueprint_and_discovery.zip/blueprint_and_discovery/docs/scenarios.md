# Scenarios & Use Cases

## 1. Customer Onboarding Workshop
- **Objective:** Document steps from lead capture to account activation.
- **Steps:**  
  1. Interview Sales, KYC, Compliance teams.  
  2. Map current state process.  
  3. Identify decision points and data sources.  
  4. Draft future-state process and data blueprint.

## 2. Claims Processing Blueprint
- **Objective:** Design a scalable claims workflow for insurance.
- **Steps:**  
  1. Gather requirement for claim intake, assessment, adjudication.  
  2. Model existing claims lifecycle in BPMN.  
  3. Define data entities: Policy, Claim, Customer, Payment.  
  4. Align on SLAs and exception handling.

## 3. Loan Approval Discovery
- **Objective:** Optimize loan decisioning by unifying manual and automated checks.
- **Steps:**  
  1. Interview credit, risk, underwriting SMEs.  
  2. Capture decision rules and data dependencies.  
  3. Draft decision strategy blueprint for next-best-action.
