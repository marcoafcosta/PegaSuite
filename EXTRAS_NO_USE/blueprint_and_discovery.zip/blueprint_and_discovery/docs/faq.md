# FAQ

**Q: How long should a workshop last?**  
A: Typically 1–2 full-day sessions per scenario, with pre-reads to streamline discussions.

**Q: What artifacts come out of discovery?**  
A: Business Capability Model, BPMN diagrams, ERD-style data models, stakeholder personas, and a workshop report.

**Q: How do we manage changes post-discovery?**  
A: Use a change log, track via Pega’s Agile WorkList, and revisit blueprints in backlog grooming sessions.

**Q: Can blueprints be generated from existing Pega apps?**  
A: Partially—Pega’s Live Data Analyzer can export inventory, but workshops ensure context and future-state vision.
