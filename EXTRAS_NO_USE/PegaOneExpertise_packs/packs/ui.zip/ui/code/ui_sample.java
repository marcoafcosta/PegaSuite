package com.example.pega.ui;

import java.util.List;
import com.pega.api.PegaAPI;

/**
 * Rich Java class for Ui, demonstrating PegaAPI invocation.
 */
public class UiDelegate {
    public void execute(List<String> items) {
        // Initialize process
        PegaAPI.runProcess("ui_process", items);
        // Process results
        items.forEach(item -> System.out.println("Processed: " + item));
    }
}
