# Ui

**Overview:** Explain the purpose and scope of Ui in Pega projects.
