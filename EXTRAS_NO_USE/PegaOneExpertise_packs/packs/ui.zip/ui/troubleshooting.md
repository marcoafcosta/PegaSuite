# Troubleshooting & Compatibility for Ui

- **BPMN**: Validate `.bpmn` in Camunda Modeler or bpmn.io; ensure correct BPMN DI and DC elements.
- **Pega XML**: Import `_pega.xml` into Dev Studio; check `xmlns` and `pyName` attributes.
- **Custom XML**: Run `xmllint --noout example_schema.xsd <xml file>` for schema validation.
- **Java Code**: Build with Maven (`mvn compile`); ensure `package com.example.pega.ui` matches directory.
- **Markdown**: Use VSCode or GitHub Preview to render; validate front-matter with `mdl`.

| Issue                | Tool              | Fix                                                  |
|----------------------|-------------------|-------------------------------------------------------|
| XML schema errors    | xmllint           | `xmllint --noout --schema example_schema.xsd $FILE`   |
| BPMN load errors     | Camunda Modeler   | Ensure namespaces and DI/DC elements are present      |
| Pega import errors   | Dev Studio        | Verify process rule XML structure and attributes      |
| Java compilation     | Maven             | Check package structure and update `pom.xml` if needed|
