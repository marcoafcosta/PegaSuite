# Cloud And Pega Cloud Services

**Overview:** Explain the purpose and scope of Cloud And Pega Cloud Services in Pega projects.
