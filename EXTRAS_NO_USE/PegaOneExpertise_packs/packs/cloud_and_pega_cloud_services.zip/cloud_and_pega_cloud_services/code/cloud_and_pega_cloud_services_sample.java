package com.example.pega.cloud_and_pega_cloud_services;

import java.util.List;
import com.pega.api.PegaAPI;

/**
 * Rich Java class for Cloud And Pega Cloud Services, demonstrating PegaAPI invocation.
 */
public class CloudAndPegaCloudServicesDelegate {
    public void execute(List<String> items) {
        // Initialize process
        PegaAPI.runProcess("cloud_and_pega_cloud_services_process", items);
        // Process results
        items.forEach(item -> System.out.println("Processed: " + item));
    }
}
