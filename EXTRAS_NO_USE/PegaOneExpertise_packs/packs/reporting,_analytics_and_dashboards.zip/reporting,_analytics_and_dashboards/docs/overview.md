# Reporting, Analytics And Dashboards

**Overview:** Explain the purpose and scope of Reporting, Analytics And Dashboards in Pega projects.
