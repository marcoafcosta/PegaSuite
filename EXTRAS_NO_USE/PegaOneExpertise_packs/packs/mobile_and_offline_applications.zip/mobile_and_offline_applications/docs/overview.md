# Mobile And Offline Applications

**Overview:** Explain the purpose and scope of Mobile And Offline Applications in Pega projects.
