package com.example.pega.mobile_and_offline_applications;

import java.util.List;
import com.pega.api.PegaAPI;

/**
 * Rich Java class for Mobile And Offline Applications, demonstrating PegaAPI invocation.
 */
public class MobileAndOfflineApplicationsDelegate {
    public void execute(List<String> items) {
        // Initialize process
        PegaAPI.runProcess("mobile_and_offline_applications_process", items);
        // Process results
        items.forEach(item -> System.out.println("Processed: " + item));
    }
}
