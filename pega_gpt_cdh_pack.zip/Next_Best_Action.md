# Module: Next-Best-Action Design

## 🔍 Summary
Use NBA Designer to align decisions with customer journey.

## ✅ Best Practices
- Align NBA with business objectives and value hierarchy.
- Use Context Dictionary to personalize experience.

## 🛠 Example
NBA: Offer premium credit card to eligible customers in retention stage.

## 🧯 Troubleshooting
- No NBA action? Check engagement policies and priority rules.

## 📚 References
[Pega Docs – Next-Best-Action](https://docs.pega.com/decision-management/nba)
