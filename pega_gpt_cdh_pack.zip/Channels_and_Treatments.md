# Module: Channels and Treatments

## 🔍 Summary
Configure how actions are delivered across multiple channels.

## ✅ Best Practices
- Use consistent message templates for each channel.
- Test channel eligibility before deployment.

## 🛠 Example
Treatment: Email Template → Linked to 5% discount offer

## 🧯 Troubleshooting
- Action not delivered? Verify treatment availability in that channel.

## 📚 References
[Pega Docs – Channels](https://docs.pega.com/customer-decision-hub/channels)
